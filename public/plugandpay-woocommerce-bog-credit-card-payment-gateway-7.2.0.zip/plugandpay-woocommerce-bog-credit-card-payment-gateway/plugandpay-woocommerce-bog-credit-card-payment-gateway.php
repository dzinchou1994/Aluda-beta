<?php
/**
 * Plugin Name: WooCommerce BOG Credit Card Payment Gateway
 * Plugin URI:  http://plugandpay.ge/
 * Description: Accept Visa/Mastercard/Amex payments in your WooCommerce shop using BOG gateway.
 * Version:     7.2.0
 * Author:      Plug and Pay Ltd.
 * Author URI:  http://plugandpay.ge/
 * License:     https://plugandpay.ge/eula
 * Domain Path: /languages
 * Text Domain: bog-gateway
 * WC requires at least: 3.0.0
 * WC tested up to: 8.4
 *
 * Intellectual Property rights, and copyright, reserved by Plug and Pay, Ltd. as allowed by law include,
 * but are not limited to, the working concept, function, and behavior of this software,
 * the logical code structure and expression as written.
 *
 * @package     WooCommerce BOG Credit Card Payment Gateway
 * @author      Plug and Pay Ltd. https://plugandpay.ge/
 * @copyright   Copyright (c) Plug and Pay Ltd. (support@plugandpay.ge)
 * @since       1.0.0
 * @license     https://plugandpay.ge/eula¬
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

( function () {
	// Composer autoload.
	require_once __DIR__ . '/vendor/autoload.php';

	add_action(
		'before_woocommerce_init',
		function () {
			if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			}
		}
	);

	if ( function_exists( 'ioncube_loader_version' ) ) {

		/**
		 * Init plugin.
		 *
		 * @param string $file Must be __FILE__ from the root plugin file.
		 * @param string $software_version Current software version of this plugin.
		 *                                 Starts at version 1.0.0 and uses SemVer - https://semver.org
		 */
		PlugandPay_WC_BOG_Credit_Card_Plugin_Factory::instance( __FILE__, '7.2.0' );

	} else {
		$ioncube_notice_text         = __( 'WooCommerce BOG Credit Card Payment Gateway requires ionCube Loader to be installed on your server. Please contact your hosting provider to install ionCube Loader. For more details check the <a href="https://plugandpay.ge/docs-2/general-manuals/ioncube/" target="_blank">Manual</a>.', 'bog-gateway' );
		$ioncube_notice_allowed_html = [
			'a' => [
				'href'   => [],
				'target' => [],
			],
		];

		add_action(
			'admin_notices',
			function () use ( $ioncube_notice_text, $ioncube_notice_allowed_html ) {
				?>
				<div class="notice notice-error">
					<p>
						<?php
						echo wp_kses(
							$ioncube_notice_text,
							$ioncube_notice_allowed_html
						);
						?>
					</p>
				</div>
				<?php
			}
		);

		add_action(
			'plugin_row_meta',
			function ( $plugin_meta, $plugin_file ) use ( $ioncube_notice_text, $ioncube_notice_allowed_html ) {
				if ( plugin_basename( __FILE__ ) === $plugin_file ) {
					$plugin_meta[] = '<span style="color: #d63638; font-weight: bold;">' . wp_kses(
						$ioncube_notice_text,
						$ioncube_notice_allowed_html
					) . '</span>';
				}

				return $plugin_meta;
			},
			10,
			2
		);
	}
} )();
